# Medical Arena | الساحة الطبية

نسخة MVP الأولى من بوت Telegram التعليمي التنافسي.

## التقنية
- Python
- aiogram 3.31
- aiohttp
- SQLite للتجربة الأولى
- Webhook على Render

## متغيرات البيئة المطلوبة
- BOT_TOKEN
- WEBHOOK_BASE_URL
- WEBHOOK_SECRET

## تشغيل Render
Build Command:
pip install -r requirements.txt

Start Command:
python main.py

## ملاحظة
SQLite مناسب للتجربة فقط على الاستضافة المجانية لأن نظام الملفات في خدمات Render المجانية غير دائم. في مرحلة الإنتاج سننتقل إلى PostgreSQL.
