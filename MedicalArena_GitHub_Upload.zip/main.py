import asyncio
import json
import os
import secrets
import sqlite3
from pathlib import Path

from aiohttp import web
from aiogram import Bot, Dispatcher, F, Router
from aiogram.filters import Command, CommandStart
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message, Update

BOT_TOKEN = os.environ.get("BOT_TOKEN", "")
WEBHOOK_BASE_URL = os.environ.get("WEBHOOK_BASE_URL", "").rstrip("/")
WEBHOOK_SECRET = os.environ.get("WEBHOOK_SECRET", "")
PORT = int(os.environ.get("PORT", "10000"))

DATA_DIR = Path(os.environ.get("DATA_DIR", "."))
DB_PATH = DATA_DIR / "medical_arena.db"
QUESTIONS_PATH = Path("questions.json")

if not BOT_TOKEN:
    raise RuntimeError("BOT_TOKEN environment variable is required")
if not WEBHOOK_BASE_URL:
    raise RuntimeError("WEBHOOK_BASE_URL environment variable is required")
if not WEBHOOK_SECRET:
    WEBHOOK_SECRET = secrets.token_urlsafe(32)

router = Router()
dp = Dispatcher()
dp.include_router(router)


def db():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS users (
                telegram_id INTEGER PRIMARY KEY,
                username TEXT,
                first_name TEXT,
                xp INTEGER NOT NULL DEFAULT 0,
                level INTEGER NOT NULL DEFAULT 1,
                rating INTEGER NOT NULL DEFAULT 1000,
                wins INTEGER NOT NULL DEFAULT 0,
                losses INTEGER NOT NULL DEFAULT 0,
                questions_answered INTEGER NOT NULL DEFAULT 0,
                correct_answers INTEGER NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.commit()


def get_or_create_user(tg_user):
    with db() as conn:
        row = conn.execute(
            "SELECT * FROM users WHERE telegram_id = ?",
            (tg_user.id,),
        ).fetchone()

        if row is None:
            conn.execute(
                """INSERT INTO users
                (telegram_id, username, first_name)
                VALUES (?, ?, ?)""",
                (tg_user.id, tg_user.username, tg_user.first_name or "لاعب"),
            )
            conn.commit()
            row = conn.execute(
                "SELECT * FROM users WHERE telegram_id = ?",
                (tg_user.id,),
            ).fetchone()
        else:
            conn.execute(
                "UPDATE users SET username = ?, first_name = ? WHERE telegram_id = ?",
                (tg_user.username, tg_user.first_name or "لاعب", tg_user.id),
            )
            conn.commit()
            row = conn.execute(
                "SELECT * FROM users WHERE telegram_id = ?",
                (tg_user.id,),
            ).fetchone()

        return row


def main_keyboard():
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="🎯 ابدأ اللعب", callback_data="play"),
            InlineKeyboardButton(text="📚 التدريب", callback_data="training"),
        ],
        [
            InlineKeyboardButton(text="⚔️ تحدي لاعب", callback_data="challenge"),
            InlineKeyboardButton(text="🏆 المتصدرون", callback_data="leaderboard"),
        ],
        [
            InlineKeyboardButton(text="👤 ملفي", callback_data="profile"),
            InlineKeyboardButton(text="📊 إحصائياتي", callback_data="stats"),
        ],
        [
            InlineKeyboardButton(text="🎖️ الإنجازات", callback_data="achievements"),
            InlineKeyboardButton(text="⚙️ الإعدادات", callback_data="settings"),
        ],
        [
            InlineKeyboardButton(text="❓ المساعدة", callback_data="help"),
        ],
    ])


def back_keyboard():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🏠 الرئيسية", callback_data="home")]
    ])


def load_questions():
    with QUESTIONS_PATH.open("r", encoding="utf-8") as f:
        return json.load(f)


def profile_text(row):
    accuracy = (
        (row["correct_answers"] / row["questions_answered"]) * 100
        if row["questions_answered"] else 0
    )
    return (
        "👤 <b>ملفي الشخصي</b>\n\n"
        f"الاسم: <b>{row['first_name']}</b>\n"
        f"المستوى: <b>{row['level']}</b>\n"
        f"⭐ XP: <b>{row['xp']}</b>\n"
        f"🏆 التقييم: <b>{row['rating']}</b>\n"
        f"⚔️ الانتصارات: <b>{row['wins']}</b>\n"
        f"💥 الخسائر: <b>{row['losses']}</b>\n"
        f"🧠 الأسئلة المجاب عنها: <b>{row['questions_answered']}</b>\n"
        f"🎯 الدقة: <b>{accuracy:.1f}%</b>"
    )


@router.message(CommandStart())
async def start_handler(message: Message):
    row = get_or_create_user(message.from_user)
    await message.answer(
        "🩺 <b>مرحباً بك في Medical Arena</b>\n"
        "<b>الساحة الطبية</b>\n\n"
        "🎮 اختبر معلوماتك الطبية.\n"
        "🧠 طوّر مستواك.\n"
        "⚔️ نافس اللاعبين.\n"
        "🏆 اصعد في قائمة المتصدرين.\n\n"
        "تم إنشاء ملفك بنجاح. اختر من القائمة:",
        reply_markup=main_keyboard(),
    )


@router.message(Command("help"))
async def help_command(message: Message):
    await message.answer(
        "❓ <b>مساعدة Medical Arena</b>\n\n"
        "/start — فتح القائمة الرئيسية\n"
        "/profile — عرض الملف الشخصي\n"
        "/ranking — عرض المتصدرين\n"
        "/help — المساعدة\n\n"
        "هذه نسخة التطوير الأولى، وستتم إضافة نظام المنافسات والبطولات تدريجياً."
    )


@router.message(Command("profile"))
async def profile_command(message: Message):
    row = get_or_create_user(message.from_user)
    await message.answer(profile_text(row), reply_markup=back_keyboard())


@router.message(Command("ranking"))
async def ranking_command(message: Message):
    await show_leaderboard(message)


async def show_leaderboard(target):
    with db() as conn:
        rows = conn.execute(
            """SELECT first_name, username, xp, rating, wins
               FROM users
               ORDER BY rating DESC, xp DESC
               LIMIT 10"""
        ).fetchall()

    if not rows:
        text = "🏆 لا يوجد لاعبون بعد."
    else:
        lines = ["🏆 <b>المتصدرون</b>\n"]
        medals = ["🥇", "🥈", "🥉"]
        for i, row in enumerate(rows, start=1):
            medal = medals[i-1] if i <= 3 else f"{i}."
            name = row["first_name"] or row["username"] or "لاعب"
            lines.append(
                f"{medal} <b>{name}</b> — ⭐ {row['xp']} XP — 🏆 {row['rating']}"
            )
        text = "\n".join(lines)

    if isinstance(target, Message):
        await target.answer(text, reply_markup=back_keyboard())
    else:
        await target.message.edit_text(text, reply_markup=back_keyboard())


async def show_training(target):
    questions = load_questions()
    q = questions[0]

    buttons = []
    for key in ["a", "b", "c", "d"]:
        buttons.append([
            InlineKeyboardButton(
                text=f"{key.upper()}) {q['options'][key]}",
                callback_data=f"answer:{q['id']}:{key}"
            )
        ])

    keyboard = InlineKeyboardMarkup(inline_keyboard=buttons + [
        [InlineKeyboardButton(text="🏠 الرئيسية", callback_data="home")]
    ])

    text = (
        "📚 <b>التدريب</b>\n\n"
        f"🧠 <b>{q['category']}</b>\n"
        f"الصعوبة: {q['difficulty']}\n\n"
        f"{q['question']}\n\n"
        "اختر الإجابة الصحيحة:"
    )
    if isinstance(target, Message):
        await target.answer(text, reply_markup=keyboard)
    else:
        await target.message.edit_text(text, reply_markup=keyboard)


@router.callback_query(F.data == "home")
async def home_callback(callback: CallbackQuery):
    await callback.message.edit_text(
        "🩺 <b>Medical Arena — الساحة الطبية</b>\n\n"
        "اختر ما تريد القيام به:",
        reply_markup=main_keyboard(),
    )
    await callback.answer()


@router.callback_query(F.data == "profile")
async def profile_callback(callback: CallbackQuery):
    row = get_or_create_user(callback.from_user)
    await callback.message.edit_text(profile_text(row), reply_markup=back_keyboard())
    await callback.answer()


@router.callback_query(F.data == "stats")
async def stats_callback(callback: CallbackQuery):
    row = get_or_create_user(callback.from_user)
    total = row["questions_answered"]
    correct = row["correct_answers"]
    accuracy = (correct / total * 100) if total else 0
    await callback.message.edit_text(
        "📊 <b>إحصائياتي</b>\n\n"
        f"🧠 الأسئلة: <b>{total}</b>\n"
        f"✅ الصحيحة: <b>{correct}</b>\n"
        f"🎯 الدقة: <b>{accuracy:.1f}%</b>\n"
        f"⚔️ الانتصارات: <b>{row['wins']}</b>\n"
        f"💥 الخسائر: <b>{row['losses']}</b>\n"
        f"⭐ XP: <b>{row['xp']}</b>",
        reply_markup=back_keyboard(),
    )
    await callback.answer()


@router.callback_query(F.data == "leaderboard")
async def leaderboard_callback(callback: CallbackQuery):
    await show_leaderboard(callback)
    await callback.answer()


@router.callback_query(F.data.in_({"training", "play"}))
async def play_callback(callback: CallbackQuery):
    await show_training(callback)
    await callback.answer()


@router.callback_query(F.data == "challenge")
async def challenge_callback(callback: CallbackQuery):
    await callback.message.edit_text(
        "⚔️ <b>تحدي لاعب</b>\n\n"
        "نظام 1 ضد 1 قيد التطوير.\n"
        "في النسخة القادمة ستتمكن من تحدي صديق أو دخول مباراة عشوائية.",
        reply_markup=back_keyboard(),
    )
    await callback.answer()


@router.callback_query(F.data == "achievements")
async def achievements_callback(callback: CallbackQuery):
    await callback.message.edit_text(
        "🎖️ <b>الإنجازات</b>\n\n"
        "🔒 الإنجازات ستُفتح تدريجياً مع تطوير نظام اللعب.\n\n"
        "أمثلة مستقبلية:\n"
        "🧫 خبير الأحياء المجهرية\n"
        "🔥 سلسلة 10 انتصارات\n"
        "🧠 100 إجابة صحيحة",
        reply_markup=back_keyboard(),
    )
    await callback.answer()


@router.callback_query(F.data == "settings")
async def settings_callback(callback: CallbackQuery):
    await callback.message.edit_text(
        "⚙️ <b>الإعدادات</b>\n\n"
        "🌐 لغة الواجهة: العربية\n"
        "🧠 لغة الأسئلة: سيتم تحديدها لاحقاً\n\n"
        "خيارات اللغات والتخصيص ستُضاف لاحقاً.",
        reply_markup=back_keyboard(),
    )
    await callback.answer()


@router.callback_query(F.data == "help")
async def help_callback(callback: CallbackQuery):
    await callback.message.edit_text(
        "❓ <b>المساعدة</b>\n\n"
        "استخدم القائمة الرئيسية للتنقل داخل الساحة الطبية.\n\n"
        "هذه النسخة هي الأساس الذي سنبني فوقه نظام المنافسات والبطولات والذكاء الاصطناعي.",
        reply_markup=back_keyboard(),
    )
    await callback.answer()


@router.callback_query(F.data.startswith("answer:"))
async def answer_callback(callback: CallbackQuery):
    _, question_id, selected = callback.data.split(":")
    question = next(q for q in load_questions() if q["id"] == question_id)
    correct = selected == question["correct"]

    with db() as conn:
        row = conn.execute(
            "SELECT * FROM users WHERE telegram_id = ?",
            (callback.from_user.id,),
        ).fetchone()

        if correct:
            xp_gain = 10
            new_xp = row["xp"] + xp_gain
            new_level = (new_xp // 100) + 1
            new_rating = row["rating"] + 5
            conn.execute(
                """UPDATE users
                   SET xp=?, level=?, rating=?,
                       questions_answered=questions_answered+1,
                       correct_answers=correct_answers+1
                   WHERE telegram_id=?""",
                (new_xp, new_level, new_rating, callback.from_user.id),
            )
        else:
            conn.execute(
                """UPDATE users
                   SET questions_answered=questions_answered+1,
                       rating=CASE WHEN rating > 1000 THEN rating-2 ELSE rating END
                   WHERE telegram_id=?""",
                (callback.from_user.id,),
            )
        conn.commit()

    if correct:
        result = (
            "✅ <b>إجابة صحيحة!</b>\n\n"
            f"⭐ +{xp_gain} XP\n"
            "🏆 +5 Rating\n\n"
            f"💡 {question['explanation']}"
        )
    else:
        result = (
            "❌ <b>إجابة غير صحيحة</b>\n\n"
            f"✅ الإجابة الصحيحة: <b>{question['correct'].upper()}) "
            f"{question['options'][question['correct']]}</b>\n\n"
            f"💡 {question['explanation']}"
        )

    await callback.message.edit_text(result, reply_markup=back_keyboard())
    await callback.answer()


async def health(request):
    return web.json_response({"status": "ok", "service": "Medical Arena"})


async def telegram_webhook(request):
    secret = request.headers.get("X-Telegram-Bot-Api-Secret-Token")
    if WEBHOOK_SECRET and secret != WEBHOOK_SECRET:
        return web.Response(status=403, text="Forbidden")

    data = await request.json()
    update = Update.model_validate(data, context={"bot": bot})
    await dp.feed_update(bot, update)
    return web.Response(text="OK")


bot = Bot(BOT_TOKEN)


async def on_startup(app):
    init_db()

    await bot.set_my_commands([
        {"command": "start", "description": "فتح الساحة الطبية"},
        {"command": "profile", "description": "عرض ملفي"},
        {"command": "ranking", "description": "عرض المتصدرين"},
        {"command": "help", "description": "المساعدة"},
    ])

    webhook_url = f"{WEBHOOK_BASE_URL}/telegram/webhook"
    await bot.set_webhook(
        webhook_url,
        secret_token=WEBHOOK_SECRET,
        drop_pending_updates=True,
    )
    print(f"Webhook configured: {webhook_url}")


async def on_cleanup(app):
    await bot.delete_webhook(drop_pending_updates=False)
    await bot.session.close()


app = web.Application()
app.router.add_get("/", health)
app.router.add_get("/health", health)
app.router.add_post("/telegram/webhook", telegram_webhook)
app.on_startup.append(on_startup)
app.on_cleanup.append(on_cleanup)


if __name__ == "__main__":
    web.run_app(app, host="0.0.0.0", port=PORT)
